import { Issue } from '../issue';
declare type Report = Issue[];
export { Report };
