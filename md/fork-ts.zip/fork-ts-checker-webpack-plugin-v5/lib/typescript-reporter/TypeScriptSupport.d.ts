import { TypeScriptReporterConfiguration } from './TypeScriptReporterConfiguration';
declare function assertTypeScriptSupport(configuration: TypeScriptReporterConfiguration): void;
export { assertTypeScriptSupport };
