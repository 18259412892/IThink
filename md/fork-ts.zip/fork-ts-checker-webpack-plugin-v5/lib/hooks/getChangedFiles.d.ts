import webpack from 'webpack';
declare function getChangedFiles(compiler: webpack.Compiler): string[];
export { getChangedFiles };
