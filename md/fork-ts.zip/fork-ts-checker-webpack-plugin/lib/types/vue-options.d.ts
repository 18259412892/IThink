export interface VueOptions {
    enabled: boolean;
    compiler: string;
}
